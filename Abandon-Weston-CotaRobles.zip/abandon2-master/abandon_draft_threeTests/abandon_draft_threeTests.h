//
//  abandon_draft_threeTests.h
//  abandon_draft_threeTests
//
//  Created by Gwendolyn Weston on 5/4/13.
//  Copyright (c) 2013 Gwendolyn Weston. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface abandon_draft_threeTests : SenTestCase

@end
