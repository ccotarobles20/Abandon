//
//  Word.m
//  abandon_draft_three
//
//  Created by Gwendolyn Weston on 5/4/13.
//  Copyright (c) 2013 Gwendolyn Weston. All rights reserved.
//

#import "Word.h"


@implementation Word

@dynamic chinese;
@dynamic chineseRecording;
@dynamic english;
@dynamic englishRecording;
@dynamic pinyin;

@end
