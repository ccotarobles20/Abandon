//
//  DictEntry.m
//  abandon_draft_three
//
//  Created by Gwendolyn Weston on 5/14/13.
//  Copyright (c) 2013 Gwendolyn Weston. All rights reserved.
//

#import "DictEntry.h"


@implementation DictEntry

@dynamic english;
@dynamic pinyin;
@dynamic simplified;
@dynamic traditional;
@dynamic mnemonic;

@end
