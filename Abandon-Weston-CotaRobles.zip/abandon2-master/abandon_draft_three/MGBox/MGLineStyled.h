//
//  Created by matt on 10/11/12.
//

#import "MGLine.h"

@interface MGLineStyled : MGLine

@end
