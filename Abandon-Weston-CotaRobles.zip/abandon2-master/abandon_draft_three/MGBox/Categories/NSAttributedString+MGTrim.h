//
//  Created by matt on 9/11/12.
//

@interface NSAttributedString (MGTrim)

- (NSAttributedString *)attributedStringByTrimming:(NSCharacterSet *)set;

@end
