//
//  Queue.m
//  abandon_draft_three
//
//  Created by Gwendolyn Weston on 5/4/13.
//  Copyright (c) 2013 Gwendolyn Weston. All rights reserved.
//

#import "Queue.h"


@implementation Queue

@dynamic name;
@dynamic notRecored;

@end
