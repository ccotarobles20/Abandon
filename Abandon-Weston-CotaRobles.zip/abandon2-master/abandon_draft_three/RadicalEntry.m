//
//  RadicalEntry.m
//  abandon_draft_three
//
//  Created by Gwendolyn Weston on 5/14/13.
//  Copyright (c) 2013 Gwendolyn Weston. All rights reserved.
//

#import "RadicalEntry.h"


@implementation RadicalEntry

@dynamic character;
@dynamic translation;

@end
